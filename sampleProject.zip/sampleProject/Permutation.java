/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue<String> queue = new RandomizedQueue<String>();
        int k = Integer.parseInt(args[0]);
        In in = new In(args[2]);      // input file
        // int n = in.readInt();
        while (!in.isEmpty()) {
            queue.enqueue(in.readString());
        }

        while (k > 0) {
            k --;
            System.out.println(queue.dequeue());
        }
        // System.out.println()
    }
}
