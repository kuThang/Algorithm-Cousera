/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdRandom;

import java.util.Arrays;

public class QuickSort {
    private static int partition( Comparable[] a, int low, int high) {
        if (low == high) return low;

        int i = low + 1;
        int j = high;

        if(i >= j) {
            if(less(a[j], a[low])) {
                exch(a, low, j);
            }
            return j;
        }
        for(;i < j;) {
            while(less(a[i], a[low])) {
                i ++;
                if(i >= high) break;
            }
            while(less(a[low], a[j])) {
                j --;
                if (j <= low) break;
            }
            if(i >= j) break;
            exch(a, i, j);
        }
        exch(a, low, j);
        return j;
    }

    private static void sort(Comparable[] a, int low, int high) {
        if(high <= low) return;
        int k = partition(a, low, high);
        sort(a, low, k - 1);
        sort( a, k + 1, high);
    }

    public static <Key extends Comparable<Key>> void sort(Key[] a)  {
        StdRandom.shuffle(a);
        sort(a, 0, a.length -1);
    }

    private static <Key extends Comparable<Key>> boolean less(Key v, Key w) {
        return v.compareTo(w) < 0;
    }

    private static <Key extends Comparable<Key>> void exch(Comparable[] a, int i, int j) {
        Comparable temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    public static void main(String[] args) {
        Integer[] arr = {3, 4, 6, 1, 5, 10, 7, 2, 1, 0};
        QuickSort.sort(arr);
        System.out.println("After sorting  int : "+ Arrays.toString(arr));

        Double [] arr2 = { 3.4, 3.2, 3.3, 1.2, 1.9, 8.3, 7.3};
        QuickSort.sort(arr2);
        System.out.println("After sorting  double : "+ Arrays.toString(arr2));

    }
}
